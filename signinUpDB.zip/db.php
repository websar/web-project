<?php
$con = mysqli_connect('localhost','root','123456789','userd');

if(mysqli_connect_errno()){
	echo 'فشل الاتصال بقاعدة البيانات';
}

?>